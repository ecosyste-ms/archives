# Parcel Plugin HTL

This is a plugin for Parcel which compiles `*.htl` (i.e. Sightly) templates into `dist/*.js` output. 

## Status

**THIS PROJECT IS DEPRECATED AND NO LONGER MAINTAINED**
