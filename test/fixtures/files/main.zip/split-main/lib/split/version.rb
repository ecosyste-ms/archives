# frozen_string_literal: true

module Split
  VERSION = "4.0.2"
end
